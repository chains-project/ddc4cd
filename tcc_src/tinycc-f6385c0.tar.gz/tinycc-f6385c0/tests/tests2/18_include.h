printf("included\n");
/* test file with missing newline */
#ifndef INCLUDE
#define INCLUDE
#endif /* INCLUDE */